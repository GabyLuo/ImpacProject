# Examples

## All Components Example (all-components.html)

This example needs to be built first. To build the examples, run webpack in this directory, and then
open `all-components.html` in your browser.

## Plugin example

If you need to write your own plugin for other Google Map components (e.g. overlays, heat maps)
refer to `overlay.html` for reference.


