<template>
  <div>
    <h1>Demos</h1>
    Click on one of the demos on the left to view them!
  </div>
</template>
