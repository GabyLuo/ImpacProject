<template>
<span>
  Refer to the
  <a href="https://developers.google.com/maps/documentation/javascript/reference">Google
  Maps Javascript API reference</a>
  for the documentation of items in this section.
</span>
</template>